DROP SCHEMA lab1 CASCADE;
CREATE SCHEMA Lab1;

CREATE TABLE Highways (
    highwayNum INT,
    length NUMERIC(4,1),
    speedLimit INT,
    PRIMARY KEY(highwayNum)
);

CREATE TABLE Exits (
    highwayNum INT REFERENCES Highways(highwayNum), 
    exitNum INT, 
    description VARCHAR(60), 
    mileMarker NUMERIC(4,1), 
    exitCity VARCHAR(20), 
    exitState VARCHAR(2), 
    isExitOpen BOOLEAN,
    PRIMARY KEY(highwayNum, exitNum)
);

CREATE TABLE Interchanges (
    highwayNum1 INT,
    exitNum1 INT, 
    highwayNum2 INT, 
    exitNum2 INT,
    PRIMARY KEY(highwayNum1, exitNum1, highwayNum2, exitNum2),
    FOREIGN KEY(highwayNum1, exitNum1) REFERENCES Exits,
    FOREIGN KEY(highwayNum2, exitNum2) REFERENCES Exits
);

CREATE TABLE Cameras (
    cameraID INT, 
    highwayNum INT REFERENCES Highways(highwayNum), 
    mileMarker NUMERIC(5,1), 
    isCameraWorking BOOLEAN,
    PRIMARY KEY(cameraID)
);

CREATE TABLE Owners (
    ownerState VARCHAR(2), 
    ownerLicenseID VARCHAR(8), 
    name VARCHAR(60), 
    address VARCHAR(60), 
    startDate DATE, 
    expirationDate DATE,   
    PRIMARY KEY(ownerState, ownerLicenseID)
);

CREATE TABLE Vehicles (
    vehicleState VARCHAR(2), 
    vehicleLicensePlate VARCHAR(7), 
    ownerState VARCHAR(2), 
    ownerLicenseID VARCHAR(8), 
    year INT, 
    color VARCHAR(2),
    PRIMARY KEY(vehicleState, vehicleLicensePlate),
    FOREIGN KEY(ownerState, ownerLicenseID) REFERENCES Owners
);

CREATE TABLE Photos (
    cameraID INT REFERENCES Cameras(cameraID), 
    vehicleState VARCHAR(2), 
    vehicleLicensePlate VARCHAR(7), 
    photoTimestamp TIMESTAMP,
    PRIMARY KEY(cameraID, photoTimestamp),
    FOREIGN KEY(vehicleState, vehicleLicensePlate) REFERENCES Vehicles
);
