SELECT DISTINCT P.cameraID as theCameraID, P.photoTimestamp as theTimestamp, O.name as theOwnerName, O.address as theOwnerAddress
FROM Highways H, Cameras C, Owners O, Vehicles V, Photos P
WHERE C.isCameraWorking = TRUE
  AND P.cameraID = C.cameraID
  AND DATE(P.photoTimestamp) = '2022-12-01'
  AND (V.color = 'RE' OR V.color = 'GR')
  AND (P.vehicleState = V.vehicleState AND P.vehicleLicensePlate = V.vehicleLicensePlate)
  AND O.name LIKE '_o%'
  AND (V.ownerState = O.ownerState AND V.ownerLicenseID = O.ownerLicenseID)
  AND H.speedLimit <= 65
  AND C.highwayNum = H.highwayNum;  
