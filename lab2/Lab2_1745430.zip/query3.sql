SELECT DISTINCT H.highwayNum, H.length
FROM Highways H
WHERE H.length > 100
  AND NOT EXISTS (SELECT *
      	      FROM Cameras C
	      WHERE H.highwayNum = C.highwayNum AND C.isCameraWorking = TRUE
	      )
ORDER BY H.length DESC;
