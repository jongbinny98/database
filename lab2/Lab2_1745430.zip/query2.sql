SELECT DISTINCT I.highwayNum1 AS h1, I.exitNum1 AS e1, I.highwayNum2 AS h2, I.exitNum2 AS e2 
FROM Interchanges I, Exits E1, Exits E2
WHERE E1.isExitOpen = TRUE AND E2.isExitOpen = TRUE
  AND E1.description = E2.description
  AND (E1.exitCity <> E2.exitCity OR E1.exitState <> E2.exitState)
  AND I.highwayNum1 = E1.highwayNum AND I.exitNum1 = E1.exitNum
  AND I.highwayNum2 = E2.highwayNum AND I.exitNum2 = E2.exitNum
