SELECT DISTINCT E1.highwayNum AS highwayNum, E1.exitNum AS firstExitNum, E2.exitNum AS secondExitNum, E2.mileMarker - E1.mileMarker AS exitDistance
FROM Exits E1, Exits E2
WHERE E1.highwayNum = E2.highwayNum
  AND E1.mileMarker < E2.mileMarker 
  AND (E2.mileMarker - E1.mileMarker) <= 5 
