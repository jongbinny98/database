-- CSE 180 Winter 2023 Lab2 create which you must modify as described in Lab2 pdf

-- The following two lines are not needed i but they're useful.
DROP SCHEMA Lab2 CASCADE;
CREATE SCHEMA Lab2;


CREATE TABLE Highways (
    highwayNum INT NOT NULL,
    length NUMERIC(4,1) NOT NULL,
    speedLimit INT,
    PRIMARY KEY (highwayNum)
);

CREATE TABLE Exits (
    highwayNum INT NOT NULL REFERENCES Highways,
    exitNum INT NOT NULL,
    description VARCHAR(60),
    mileMarker NUMERIC(4,1) NOT NULL,
    exitCity VARCHAR(20),
    exitState CHAR(2),
    isExitOpen BOOL,
    PRIMARY KEY (highwayNum, exitNum),
    UNIQUE (highwayNum, mileMarker)
);

CREATE TABLE Interchanges (
    highwayNum1 INT NOT NULL,
    exitNum1 INT NOT NULL,
    highwayNum2 INT NOT NULL,
    exitNum2 INT NOT NULL,
    FOREIGN KEY (highwayNum1, exitNum1) REFERENCES Exits(highwayNum, exitNum),
    FOREIGN KEY (highwayNum2, exitNum2) REFERENCES Exits(highwayNum, exitNum),
    PRIMARY KEY (highwayNum1, exitNum1, highwayNum2, exitNum2)
);

CREATE TABLE Cameras (
    cameraID INT NOT NULL,
    highwayNum INT REFERENCES Highways(highwayNum),
    mileMarker NUMERIC(4,1) NOT NULL,
    isCameraWorking BOOL,
    PRIMARY KEY (cameraID)
);

CREATE TABLE Owners (
    ownerState CHAR(2) NOT NULL,
    ownerLicenseID CHAR(8) NOT NULL,
    name VARCHAR(60),
    address VARCHAR(60),
    startDate DATE,
    expirationDate DATE,
    PRIMARY KEY (ownerState, ownerLicenseID),
    UNIQUE (name, address)
);

CREATE TABLE Vehicles (
    vehicleState CHAR(2) NOT NULL,
    vehicleLicensePlate CHAR(7) NOT NULL,
    ownerState CHAR(2),
    ownerLicenseID CHAR(8),
    year INT,
    color CHAR(2),
    FOREIGN KEY (ownerState, ownerLicenseID) REFERENCES Owners,
    PRIMARY KEY (vehicleState, vehicleLicensePlate)
);

CREATE TABLE Photos (
    cameraID INT NOT NULL REFERENCES Cameras,
    vehicleState CHAR(2) NOT NULL,
    vehicleLicensePlate Char(7) NOT NULL,
    photoTimestamp TIMESTAMP NOT NULL,
    FOREIGN KEY (vehicleState, vehicleLicensePlate) REFERENCES Vehicles,
    PRIMARY KEY (cameraID, photoTimestamp),
    UNIQUE (vehicleState, vehicleLicensePlate, photoTimestamp)
);
